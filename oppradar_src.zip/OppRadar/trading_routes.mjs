// M8-P6 | trading_routes.mjs

import { validateSignal } from './trading_signal.mjs';
import { processSignal } from './trading_order_engine.mjs';
import { executePaper } from './trading_executor_paper.mjs';
import { DB } from './db.mjs';
import * as killSwitch from './trading_kill_switch.mjs';
import { safeLog, sanitizeError } from './trading_log_sanitizer.mjs';

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch (e) { reject(new Error('invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

/**
 * Register trading routes on the raw http server request handler.
 * Call from inside the http.createServer callback.
 * Returns true if a route was matched (response sent), false otherwise.
 */
export async function handleTradingRoute(req, res, pathname, query) {

  // POST /trading/signal
  if (pathname === '/trading/signal' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      validateSignal(body);
      const procResult = await processSignal(body);
      if (procResult.status === 'REJECTED') {
        return json(res, 200, {
          signal_id: body.signal_id,
          order_id: null,
          order_status: 'REJECTED',
          fill_status: null,
        });
      }
      // Fetch the created order
      const rows = await DB.allSql('SELECT * FROM trading_orders WHERE order_id = ?', [procResult.order_id]);
      const order = rows[0];
      const fillResult = await executePaper(order);
      return json(res, 200, {
        signal_id: body.signal_id,
        order_id: procResult.order_id,
        order_status: fillResult.status,
        fill_status: fillResult.status,
      });
    } catch (err) {
      if (err.message && (err.message.includes('is required') || err.message.includes('must be') || err.message.includes('invalid JSON'))) {
        return json(res, 400, { error: 'validation failed', detail: err.message });
      }
      safeLog('error', '[TradingRoutes] signal error:', sanitizeError(err));
      return json(res, 500, { error: 'internal error', detail: err.message });
    }
  }

  // GET /trading/orders/:order_id
  if (pathname.startsWith('/trading/orders/') && pathname !== '/trading/orders' && req.method === 'GET') {
    const orderId = pathname.slice('/trading/orders/'.length);
    try {
      const orders = await DB.allSql('SELECT * FROM trading_orders WHERE order_id = ?', [orderId]);
      if (orders.length === 0) {
        return json(res, 404, { error: 'order not found' });
      }
      const order = orders[0];
      const fills = await DB.allSql('SELECT * FROM trading_fills WHERE order_id = ?', [orderId]);
      const snapshots = await DB.allSql('SELECT * FROM trading_snapshots WHERE order_id = ?', [orderId]);
      return json(res, 200, {
        order,
        fill: fills.length > 0 ? fills[0] : null,
        snapshot: snapshots.length > 0 ? snapshots[0] : null,
      });
    } catch (err) {
      safeLog('error', '[TradingRoutes] order lookup error:', sanitizeError(err));
      return json(res, 500, { error: 'internal error', detail: err.message });
    }
  }

  // GET /trading/orders
  if (pathname === '/trading/orders' && req.method === 'GET') {
    try {
      const status = query.status || null;
      const opp_id = query.opp_id || null;
      let limit = parseInt(query.limit) || 50;
      if (limit > 200) limit = 200;
      const offset = parseInt(query.offset) || 0;

      let where = [];
      let params = [];
      if (status) { where.push('status = ?'); params.push(status); }
      if (opp_id) { where.push('opp_id = ?'); params.push(opp_id); }
      const whereClause = where.length > 0 ? ' WHERE ' + where.join(' AND ') : '';

      const countRows = await DB.allSql(`SELECT COUNT(*) as cnt FROM trading_orders${whereClause}`, params);
      const total = countRows[0]?.cnt || 0;
      const orders = await DB.allSql(
        `SELECT * FROM trading_orders${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
        [...params, limit, offset]
      );
      return json(res, 200, { orders, total, limit, offset });
    } catch (err) {
      safeLog('error', '[TradingRoutes] orders list error:', sanitizeError(err));
      return json(res, 500, { error: 'internal error', detail: err.message });
    }
  }

  // POST /trading/kill
  if (pathname === '/trading/kill' && req.method === 'POST') {
    killSwitch.activate();
    const result = await killSwitch.cancelAllPending();
    return json(res, 200, {
      status: 'KILL_SWITCH_ACTIVATED',
      cancelled_orders: result.cancelled,
      message: 'Kill switch activated, all pending orders cancelled',
    });
  }

  // GET /trading/account
  if (pathname === '/trading/account' && req.method === 'GET') {
    try {
      await DB.runSql(`CREATE TABLE IF NOT EXISTS global_config (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)`);
      const rows = await DB.allSql("SELECT value FROM global_config WHERE key = 'virtual_notional'");
      const balance = rows.length > 0 ? parseFloat(rows[0].value) : 100;
      return json(res, 200, { mode: 'paper', balance, currency: 'USD' });
    } catch (err) {
      return json(res, 200, { mode: 'paper', balance: 100, currency: 'USD' });
    }
  }

  // POST /trading/virtual_deposit
  if (pathname === '/trading/virtual_deposit' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const amount = parseFloat(body.amount);
      if (!amount || amount <= 0 || amount > 1000000) {
        return json(res, 400, { error: 'amount must be a positive number up to 1000000' });
      }
      await DB.runSql(`CREATE TABLE IF NOT EXISTS global_config (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)`);
      await DB.runSql(
        `INSERT OR REPLACE INTO global_config (key, value, updated_at) VALUES ('virtual_notional', ?, ?)`,
        [String(amount), new Date().toISOString()]
      );
      return json(res, 200, { ok: true, balance: amount });
    } catch (err) {
      return json(res, 500, { error: 'internal error', detail: err.message });
    }
  }

  return false; // no route matched
}
