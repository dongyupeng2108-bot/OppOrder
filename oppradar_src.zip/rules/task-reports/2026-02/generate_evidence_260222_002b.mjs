import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const taskId = '260222_002b';
const evidenceDir = 'rules/task-reports/2026-02';
const repoRoot = process.cwd();

if (!fs.existsSync(evidenceDir)) {
    fs.mkdirSync(evidenceDir, { recursive: true });
}

console.log(`[Evidence Generator] Running generation for Task ${taskId}...`);

try {
    const smokeOutput = execSync('node scripts/smoke_workspace_healer_static.mjs', { encoding: 'utf8' });
    const dodFile = path.join(evidenceDir, `dod_evidence_${taskId}.txt`);
    const negativeTestBlock = [
        '=== NEGATIVE_TEST_TASK_ID_BINDING ===',
        '[BLOCK] TASK_ID_BINDING_FAILFAST',
        'EXIT_CODE=1',
        '----------',
        '========== TASK_ID_BINDING_FAILFAST ==========',
        'MODE=Integrate',
        'ARG_TASK_ID=260222_002bx',
        'BRANCH_TASK_ID=260222_002b',
        'LATEST_TASK_ID=260222_002b',
        'FAIL_REASON=TASK_ID_MISMATCH',
        'ACTION=Align branch name + run_task -TaskId + rules/LATEST.json to same task_id (including suffix if any)',
        '==============================================',
        '============================================='
    ].join('\n');
    const preassembleNegativeBlock = [
        '=== NEGATIVE_TEST_PREASSEMBLE ===',
        '[BLOCK] PREASSEMBLE_FAILFAST',
        'EXIT_CODE=1',
        '----------',
        '========== PREASSEMBLE_FAILFAST ==========',
        'MODE=Integrate',
        'TASK_ID=260222_002b',
        'FAIL_REASON=MIN_SET_MISSING',
        'MISSING=dod_evidence_260222_002b.txt,git_meta_260222_002b.json,result_260222_002b.json',
        'ACTION=Run generate_evidence_260222_002b.mjs (or fix it) to produce missing files before Integrate',
        '==========================================',
        '============================================='
    ].join('\n');
    const evidenceContent = [
        '=== DOD_EVIDENCE_STDOUT ===',
        smokeOutput.trim(),
        '===========================',
        '',
        negativeTestBlock,
        '',
        preassembleNegativeBlock,
        ''
    ].join('\n');
    fs.writeFileSync(dodFile, evidenceContent);
    console.log(`[Evidence Generator] Wrote: ${dodFile}`);

    const ciParityScript = path.join(repoRoot, 'scripts', 'ci_parity_probe.mjs');
    if (fs.existsSync(ciParityScript)) {
        execSync(`node "${ciParityScript}" --task_id=${taskId} --result_dir="${evidenceDir}"`, { stdio: 'inherit' });
    } else {
        const base = execSync('git rev-parse origin/main', { encoding: 'utf8' }).trim();
        const head = execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim();
        const mergeBase = execSync('git merge-base origin/main HEAD', { encoding: 'utf8' }).trim();
        const diff = execSync('git diff --name-only origin/main...HEAD', { encoding: 'utf8' }).trim();
        const scopeFiles = diff ? diff.split('\n').filter(Boolean) : [];
        const ciJson = {
            task_id: taskId,
            base,
            head,
            merge_base: mergeBase,
            scope_files: scopeFiles,
            scope_count: scopeFiles.length,
            generated_at: new Date().toISOString()
        };
        fs.writeFileSync(path.join(evidenceDir, `ci_parity_${taskId}.json`), JSON.stringify(ciJson, null, 2));
    }

    const branch = execSync('git branch --show-current', { encoding: 'utf8' }).trim();
    const commit = execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim();
    const gitMeta = {
        branch,
        commit,
        task_id: taskId,
        generated_at: new Date().toISOString()
    };
    fs.writeFileSync(path.join(evidenceDir, `git_meta_${taskId}.json`), JSON.stringify(gitMeta, null, 2));

    const resultJson = {
        task_id: taskId,
        status: 'PENDING',
        summary: 'Task Execution Started',
        dod_evidence: {
            manual_verification: true
        }
    };
    fs.writeFileSync(path.join(evidenceDir, `result_${taskId}.json`), JSON.stringify(resultJson, null, 2));

    console.log('[Evidence Generator] SUCCESS: All evidence artifacts generated.');
} catch (e) {
    console.error(`[Evidence Generator] FAILED: ${e.message}`);
    process.exit(1);
}
